public class Main {
  public static void main(String[] args) {
    int numeroIF = 7;
    int numeroWhile = -2;
    var estacion = "verano";

    if (numeroIF > 0) {
      System.out.println("Es positivo");
    } else if (numeroIF < 0) {
      System.out.println("Es negativo");
    } else {
      System.out.println("Es cero");
    }

    while (numeroWhile < 3) {
      System.out.println("Bucle while =" + numeroWhile);
      numeroWhile = numeroWhile + 1;
    }

    do {
      System.out.println("Bucle do =" + numeroWhile);
      numeroWhile = numeroWhile + 1;
    } while(numeroWhile < 3);

    for (int numeroFor = 0; numeroFor <= 3; numeroFor = numeroFor + 1) {
      System.out.println("For = " + numeroFor);
    }

    switch (estacion) {
      case "invierno":
        System.out.println("Es invierno");
        break;
      case "verano":
        System.out.println("Es verano");
        break;
      case "otoño":
        System.out.println("Es otoño");
        break;
      case "primavera":
        System.out.println("Es primavera");
        break;
      default:
        System.out.println("Esto no es una estación");
    }
  }
}